from django.contrib import admin
from.models import employee,Position
# Register your models here.
admin.site.register(employee)
admin.site.register(Position)
