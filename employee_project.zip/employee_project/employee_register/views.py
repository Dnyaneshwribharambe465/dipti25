from django.shortcuts import render,redirect
from django.http import HttpResponse
from .forms import employeeform
from .models import employee
#from django.http import HttpResponse
# Create your views here.
def employee_list(request):
    context = {'employee_list':employee.objects.all()}
    return render(request,"employee_list.html",context)

def employee_form(request, id=0):
    if request.method == "GET":
        if id == 0:
            form = employeeform()
        else:
             employee = employee.objects.get(pk=id)
             form = employeeform(instance=employee)
        return render(request,"employee_form.html",{'form':form})
    else:
        if id == 0:
            form = employeeform(request.POST)
        else:
            employee = employee.objects.get(pk=id)
            form = employeeform(request.POST,instance=employee)
        if form.is_valid():
            form.save()
        return redirect("list")


def employee_delete(request,id):
    employee = employee.objects.get(pk=id)
    employee.delete()
    return redirect('list')
